package com.bfhl.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BfhlApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BfhlApiApplication.class, args);
	}

}
